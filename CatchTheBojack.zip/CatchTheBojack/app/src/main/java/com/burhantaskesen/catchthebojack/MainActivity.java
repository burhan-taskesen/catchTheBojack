package com.burhantaskesen.catchthebojack;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.gridlayout.widget.GridLayout;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    Intent myIntent;
    SharedPreferences kaydedilenler;

    Runnable sureSayac;
    Runnable run;
    Handler hand = new Handler();

    GridLayout myGrid;
    View element;
    TextView skorText;
    TextView kalanSure;
    TextView highScore;

    int skor;
    int rasgele = -1;
    double kalan;
    int hiz = 500;
    int yuksekskor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        highScore = findViewById(R.id.highScore);
        myGrid = findViewById(R.id.myGrid);
        skorText = findViewById(R.id.textView);
        kalanSure = findViewById(R.id.kalanSure);
        kaydedilenler = this.getSharedPreferences("com.burhantaskesen.catchthebojack", Context.MODE_PRIVATE);
        yuksekskor = kaydedilenler.getInt("highScore",0);
        highScore.setText("HS : " + yuksekskor);
        //kaydedilenler.edit().clear().apply();

        //resimleriGizle();

        skor = 0;
        kalan = 50;

        myIntent = new Intent(MainActivity.this,MainActivity.class);

        sureSayac = new Runnable() {
            @Override
            public void run() {
                kalan -= 1;
                if(kalan <= 0){
                    hand.removeCallbacks(run);

                    if(skor > yuksekskor)
                        kaydedilenler.edit().putInt("highScore",skor).apply();

                    AlertDialog.Builder myAlert = new AlertDialog.Builder(MainActivity.this);
                    myAlert.setTitle("Game Over");
                    myAlert.setMessage("Try again ?");
                    myAlert.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialogInterface, int i) {
                            recreate();
                            //startActivity(myIntent);
                            skor = 0;
                        }
                    });
                    myAlert.setNegativeButton("No", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialogInterface, int i) {
                            System.exit(0);
                        }
                    });
                    myAlert.setCancelable(false);


                    kalanSure.setText("0.0");


                    myAlert.show();

                }
                else {

                    kalanSure.setText("" + (int)kalan/10 + "." + (int)kalan%10);
                    hand.postDelayed(sureSayac, 100);
                }
            }
        };

        hand.post(sureSayac);
    }

    @Override
    protected void onResume() {
        run = new Runnable() {
            @Override
            public void run() {
                /*
                element = myGrid.getChildAt(skor);
                element.setVisibility(View.VISIBLE);
                SystemClock.sleep(1000);
                hand.postDelayed(run,1000);

                 */
                while(true){
                    int tmp = (int) Math.round(Math.random()*11);
                    if(tmp != rasgele){
                        rasgele = tmp;
                        break;
                    }
                }

                resimleriGizle();
                elemanGoster(rasgele);

                hand.postDelayed(run,hiz);
            }
        };
        hand.post(run);
        super.onResume();
    }

    public void degistirButonFunc(View view){
        //element = myGrid.getChildAt(rasgele);
        resimleriGizle();
        hand.removeCallbacks(run);
        hand.post(run);

        skor++;
        kalan += 3;
        if(kalan>50)
            kalan=50;

        skorText.setText("Skor : " + skor);
    }

    public void resimleriGizle(){
        for(int i = 0; i < myGrid.getChildCount()-1; i++){
            element = myGrid.getChildAt(i);
            element.setVisibility(View.INVISIBLE);
        }
        skorText.setVisibility(View.VISIBLE);
        highScore.setVisibility(View.VISIBLE);
    }

    public void elemanGoster(int index){
        element = myGrid.getChildAt(index);
        element.setVisibility(View.VISIBLE);
    }
}