package com.burhantaskesen.catchthebojack;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;
import android.content.Context;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    SharedPreferences kaydedilenler;
    Runnable sureSayac;
    Runnable run;
    Handler hand = new Handler();
    ImageView resim;
    TextView skorText;
    TextView kalanSure;
    TextView highScore;
    ConstraintLayout myScreen;
    int skor;
    int rasgele = -1;
    double kalan;
    int hiz = 500;
    int yuksekskor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        resim = findViewById(R.id.imageView2);
        myScreen = findViewById(R.id.constraintLayout);
        highScore = findViewById(R.id.yuksekSkorText);
        skorText = findViewById(R.id.skorText);
        kalanSure = findViewById(R.id.kalanSureText);
        kaydedilenler = this.getSharedPreferences("com.burhantaskesen.catchthebojack", Context.MODE_PRIVATE);
        yuksekskor = kaydedilenler.getInt("highScore",0);
        highScore.setText("HS : " + yuksekskor);
        //kaydedilenler.edit().clear().apply();
        skor = 0;
        kalan = 55;

        sureSayac = new Runnable() {
            @Override
            public void run() {
                kalan -= 1;
                if(kalan <= 0){
                    if(skor > yuksekskor)
                        kaydedilenler.edit().putInt("highScore",skor).apply();

                    AlertDialog.Builder myAlert = new AlertDialog.Builder(MainActivity.this);
                    myAlert.setTitle("Game Over");
                    myAlert.setMessage("Try again ?");
                    myAlert.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialogInterface, int i) {
                            recreate();
                        }
                    });
                    myAlert.setNegativeButton("No", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialogInterface, int i) {
                            System.exit(0);
                        }
                    });
                    myAlert.setCancelable(false);

                    kalanSure.setText("0.0");

                    myAlert.show();
                    hand.removeCallbacks(run);
                }
                else {

                    kalanSure.setText("" + (int)kalan/10 + "." + (int)kalan%10);
                    hand.postDelayed(sureSayac, 100);
                }
            }
        };
        hand.post(sureSayac);
    }

    @Override
    protected void onResume() {
        run = new Runnable() {
            @Override
            public void run() {
                if(kalan > 0) {
                    int x = (int) ((Math.random() * (myScreen.getWidth() - resim.getWidth() - 1)));
                    int y = (int) ((Math.random() * (myScreen.getHeight() - resim.getHeight() - 1)));
                    resim.setX(x);
                    resim.setY(y);

                    hand.postDelayed(run, hiz);
                }
            }
        };
        hand.post(run);
        super.onResume();
    }



    public void girisYap(View view){
        hand.removeCallbacks(run);
        hand.post(run);


        if(view.getContentDescription().toString().matches("resim")){
            skor++;
            kalan += 3;
        }
        else
            kalan -= 2;

        if(kalan>55)
            kalan=55;

        skorText.setText("Skor : " + skor);
    }
}